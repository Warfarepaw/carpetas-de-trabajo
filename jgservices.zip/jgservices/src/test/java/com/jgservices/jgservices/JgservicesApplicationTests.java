package com.jgservices.jgservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JgservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
